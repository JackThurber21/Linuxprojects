#!/bin/bash
# 1 - show all lines that contain the word raven
echo "Problem 1"
grep -c raven raven.txt
# 2 - show all line numbers that are blank
echo "Problem 2"

# 3 - show all lines that contain 'rep' 'word' or 'more'
echo "Problem 3"

# 4 - show all lines with v,z,j or I in the them
echo "Problem 4"

# 5 - show all lines that end with a dash
echo "Problem 5"

# 6 - lines that don't start with uppercase
echo "Problem 6"

# 7 - Pick out all lines that contain the word 'more'.
echo "Problem 7"

# 8 - Count the number of lines that contain 'whose'
echo "Problem 8"

# 9 - count nevermore regardless of case
echo "Problem 9"

# 10 - count lines that don't contain raven
echo "Problem 10"

