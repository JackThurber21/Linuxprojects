#!/bin/bash
# Jack Thurber Assignment 5 

echo "Creating ADE School File"
#cuts the second value of each line with the comma delimiter making a list of school names.
echo  "$(cut -f 2 -d ',' ade-district.csv)" > ade-schools.csv
echo "Creating ADE Enrollment File"
# cuts the values of school name, district ,and total enrollment and places the into a new file ade-enrollment.csv
echo "$(cut -f 2,3,6 -d ',' ade-district.csv)" > ade-enrollment.csv
echo "Creating ADE Output File"
# This cuts the ehader off of ade-district.csv and sorts the school district and enrollment in ascending and descending order.
tail -n +2 ade-district.csv > ade-output.csv
echo "$(sort -f -k 2 ade-output.csv)" > ade-output.csv
echo "Finished! Thank you!"
