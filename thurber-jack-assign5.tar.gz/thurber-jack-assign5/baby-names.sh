#!/bin/bash
#Jack Thurber
echo " Common boy Baby names between 2006 and 2016 are: "
# cuts the files for the boys names exclusively and places them into two seperate files to be sorted
echo "$(cut -f 2 -d '	' 2006-baby-names.txt)" > 2006-boy-names.txt
echo "$(cut -f 2 -d '	' 2016-baby-names.txt)" > 2016-boy-names.txt
#sorts both files names to join later
echo "$(sort 2006-boy-names.txt)" > 2006-boy-names.txt
echo "$(sort 2016-boy-names.txt)" > 2016-boy-names.txt
#joins the two files together leaving only the common names
echo "$(join 2006-boy-names.txt 2016-boy-names.txt)"
