#!/bin/bash
#Jack Thurber
name=${0##*/}
directory= $1


if [ ! -d $1 ]; then
	echo "Please use a valid directory"
	echo "Usage: ./$name [directory]"
	exit 1
fi
for files in "$directory"; do
	echo "The number of files in $1 is : "
       	ls -1 | wc -l
done

