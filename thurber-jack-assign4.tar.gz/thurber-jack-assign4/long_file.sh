#!/bin/bash

name=${0##*/}
FILES=${1-'pwd'}
length=0
filename=

if [ ! -d $1 ]; then
	echo "'$1' is not a directory"
	echo "Usage: ./$name [directory]"
	exit 1
	fi

	for file in $FILES; do
		len= `echo "$file" | wc -c` 
		if [ $len -gt $length ]; then
			length= $len
			filename= $file
			fi
		done

echo "Directory: $1"
echo "Longest Filename: $filename"
echo "Longest Filename Length: $length"
