#!/bin/bash
#Jack Thurber
#5/3/2021
#Semester Project

# Parameters Check
if (($# !=3)); then 
	echo "Usage: $0 remote server remote user remote file" ; exit 1
fi

#Declare Variables

remote_server="$1"
remote_user="$2"
remote_file="$3"
src_file="$(basename $remote_file)"

function rm_temps() {
	read -p "Delete Temporary Files? (Y/N): "
	if [[ $REPLY = [Yy] ]]; then
		rm *.tmp
		rm MOCK*
		rm *.csv
		echo "Temp files deleted."
	fi
}

# 1) SCP file from remote server to local server
printf "1) Securely copying remote file: $3 -- Complete\n"
$(scp jthurber1@40.69.135.45:/home/shared/MOCK_MIX_v2.1.csv.bz2 /home/jthurber/semester_project)

# 2) Extract the contents of the securely copied file
bunzip2 $src_file
main_file="${src_file%.*}"
printf "2) Unzipping of $main_file -- complete\n"

# 3) Remove the header from the file
tail -n +2 "$main_file" > "01_rm_header.tmp"
printf "3) Removed header from main file -- complete\n"

# 4) Convert all text to lower case
tr '[:upper:]' '[:lower:]' < "01_rm_header.tmp" >"02_conv_lower.tmp"
printf "4) Converted all text to lowercase -- complete\n"

# 5) Convert Gender to m or f
printf "5) Converted all genders in the column to either M or F (male or female) -- Complete\n"
awk 'BEGIN {FS = ","; OFS =","} {
if ($5 ~ /male/) {$5 = "m"; print}
if ($5 ~ /0/) {$5 = "m"; print} 
else if ($5 ~ /female/) {$5 = "f"; print}
else if ($5 ~ /1/) {$5 = "f"; print}
else {$5 = "u"; print}
}' <"02_conv_lower.tmp" > "03_conv_gender.tmp"

# 6) FIlter records out of state with bad values
printf "5) Filtering out all states with no or NA values -- Complete\n"
awk 'BEGIN {FS = ","; OFS = ","} {
if ($12 ~// ) {$12 = $12; print}
}' <"03_conv_gender.tmp" > "04_filter_data.tmp"

# 7) Remove $ from purchase amount
printf "7) Removing the $ from the purchase amount tab -- Complete\n"
tr -d '$' <"04_filter_data.tmp" > "05_cleanup.tmp" 

# 8) Sort file by customerID
printf "8) Sort the File by the customers Id -- Complete\n"
echo "$(sort -t',' -k 2 05_cleanup.tmp)" > "transaction.csv"

# 9) Accumulate Purchase amount
printf "9) Accumulating purchase amount -- complete\n"
awk 'BEGIN {FS = ",";OFS = ","} {
arr_custid[$1]+=$6


	printf "%s,%s,%s,%s,%s\n" , $1, $12, $13, $3, $2
	for (id in arr_custid)
		{printf "%-10s $s\n", id, arr_custid[id]}
}' <"transaction.csv" > "summary.csv" 
echo "$(sort summary.csv | uniq -u)" > "summary.csv"
# 10) Sort the summary file
printf "10) Sorting the summary file based on priority -- complete\n"
echo "$(sort -t',' -k 6 summary.csv)" >"summary.csv"
echo "$(sort -t',' -k 13 summary.csv)" >"summary.csv"
echo "$(sort -t',' -k 3 summary.csv)" >"summary.csv"
echo "$(sort -t',' -k 2 summary.csv)" >"summary.csv"
# 11a) gnereate transaction report
printf "11-a) Generating transaction report -- complete\n"
awk 'BEGIN {FS =","; OFS =","  } {
arr_transaction[$6]+=$6
}
END {	printf "%s\n" , "Transaction Count Report"
	printf "%s %s %s \n" , "State","Gender","Transaction Count"
	
}' <"transaction.csv" >"transaction-rpt"

# 11b) Generate purchase report
printf "11-b) Generating purchase report -- Complete\n"
awk 'BEGIN {FS = ","; OFS = ","} {
}
END { 
	printf "%s\n" , "Purchase Summary Report"
	printf "%s %s %s \n" , "State","Gender","Purchase Amount"

}' <"transaction.csv" >"purchase-rpt"
# 13) Remove Temp files
rm_temps # calls the removal function for .tmp files
