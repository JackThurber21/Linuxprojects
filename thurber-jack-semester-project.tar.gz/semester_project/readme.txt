Welcome to my semester project.

The only thing to note that the program does not tell you is that after running it for the first time
Step 9 may take a while to finish loading. If it just sits for a second the rest of the program will finish and you can hit y or n to delete the files


Thank You
Jack Thurber

p.s. I really enjoyed this class I thought it was structured well and I actually learned a whole lot so thank you very much!.
