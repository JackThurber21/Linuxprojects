#!/bin/bash
trap 'echo PROGRAM INTERUPTED; exit 1' INT
while true
do 
	echo "program running"
	sleep 1
done
