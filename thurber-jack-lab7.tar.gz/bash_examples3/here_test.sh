#!/bin/bash
grep -i "$1" <<+
Max June 22
Barbara February 3
Darlene May 8
Helen March 13
Zach January 23
Nancy June 26
+
