#!/bin/bash
who
exec date
echo "Does this line get displayed?"
