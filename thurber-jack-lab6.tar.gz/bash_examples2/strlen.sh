#!/bin/bash
myvar="one eyed one horned flying purple peaopl eater"
varlen=${#myvar}
echo "String lenght is $varlen"
